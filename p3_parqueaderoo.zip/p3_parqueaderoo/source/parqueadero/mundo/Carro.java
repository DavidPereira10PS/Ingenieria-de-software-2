package parqueadero.mundo;

public class Carro {

    Carro(String pPlaca, int horaActual) {
    
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
  
       
    
    
    
    }

    int darTiempoEnParqueadero(int horaActual) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    String darPlaca() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
        
         }
    boolean tienePlaca(boolean pPlaca) {
        
                    return pPlaca == pPlaca;
                    
                    
            
            
        }
        
    }

    


